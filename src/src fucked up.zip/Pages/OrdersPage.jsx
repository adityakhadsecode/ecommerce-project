import { Header } from "../Components/Header";
import { useEffect, useState, Fragment } from "react";
import axios from "axios";
import "./OrdersPage.css";
import dayjs from "dayjs";
import formatMoney from "../utils/money";

export function OrdersPage({ cart }) {
  const [orders, setOrders] = useState([]);
  useEffect(() => {
    axios.get("/api/orders?expand=products").then((response) => {
      setOrders(response.data);
    });
  }, []);
  return (
    <>
      <title>Orders</title>
      <Header cart={cart} />

      <div className="orders-page">
        <div className="page-title">Your Orders</div>
        <div className="orders-grid">
          {orders.length === 0 ? (
            <div className="no-orders">You have no orders yet.</div>
          ) : (
            orders.map((order) => (
              <div key={order.id} className="order-container">
                <div className="order-header">
                  <div className="order-header-left-section">
                    <div className="order-date">
                      <div className="order-header-label">Order Placed:</div>
                      <div>{dayjs(order.orderTimeMs).format("MMMM D")}</div>
                    </div>
                    <div className="order-total">
                      <div className="order-header-label">Total:</div>
                      <div>{formatMoney(order.totalCostCents)}</div>
                    </div>
                  </div>

                  <div className="order-header-right-section">
                    <div className="order-header-label">Order ID:</div>
                    <div>{order.id}</div>
                  </div>
                </div>

                <div className="order-details-grid">
                  {!order.products || order.products.length === 0 ? (
                    <div className="no-products">
                      No products available for this order.
                    </div>
                  ) : (
                    order.products.map((OrderProduct) => {
                      const product = OrderProduct.product || {};
                      return (
                        <Fragment key={product.id || OrderProduct.productId}>
                          <div className="product-image-container">
                            <img
                              src={product.image || ""}
                              alt={product.name || "Product"}
                            />
                          </div>

                          <div className="product-details">
                            <div className="product-name">
                              {product.name || "Unnamed product"}
                            </div>
                            <div className="product-delivery-date">
                              Arriving on:{" "}
                              {dayjs(
                                OrderProduct.estimatedDeliveryTimeMs,
                              ).format("MMMM D")}
                            </div>
                            <div className="product-quantity">
                              Quantity: {OrderProduct.quantity}
                            </div>
                            <button className="buy-again-button button-primary">
                              <img
                                className="buy-again-icon"
                                src="images/icons/buy-again.png"
                              />
                              <span className="buy-again-message">
                                Add to Cart
                              </span>
                            </button>
                          </div>

                          <div className="product-actions">
                            <a href="/tracking">
                              <button className="track-package-button button-secondary">
                                Track package
                              </button>
                            </a>
                          </div>
                        </Fragment>
                      );
                    })
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </>
  );
}
